local addonName, ns = ...
RT = ns -- Робимо простір імен доступним для всіх файлів
ReagentTracker = RT

local defaults = {
    enabled = {},
    showExpansion = {},
    goals = {},
    iconSize = 32,
    counterFontSize = 12,
    nameFontSize = 14,
    showNames = true,
    showCountOnIcon = true,
    showCountInName = true,
    orientation = "Vertical",
    textPosition = "Right",
    scale = 1,
    locked = false,
    spacing = 6,
    position = { point = "CENTER", relativePoint = "CENTER", x = 0, y = 0 },
}

local function CopyDefaults(src, dst)
    if type(dst) ~= "table" then dst = {} end
    for k, v in pairs(src) do
        if type(v) == "table" then dst[k] = CopyDefaults(v, dst[k])
        elseif dst[k] == nil then dst[k] = v end
    end
    return dst
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("BAG_UPDATE_DELAYED")

f:SetScript("OnEvent", function(_, event, addon)
    if event == "ADDON_LOADED" and addon == "ReagentTracker" then
        ReagentTrackerDB = CopyDefaults(defaults, ReagentTrackerDB or {})
        RT.db = ReagentTrackerDB
    end

    if event == "PLAYER_LOGIN" then
        -- Викликаємо функції лише якщо вони завантажені з tracker.lua
        if RT.CreateTracker then
            RT:CreateTracker()
            C_Timer.After(1, function() RT:UpdateTracker() end)
        end
    end

    if event == "BAG_UPDATE_DELAYED" then
        if RT.UpdateTracker then RT:UpdateTracker() end
    end
end)

StaticPopupDialogs["RT_SET_GOAL"] = {
    text = "Set goal for this reagent (0 to reset):",
    button1 = "Set",
    button2 = "Cancel",
    hasEditBox = 1,
    maxLetters = 5,
    OnAccept = function(self, data)
        local val = tonumber(self.editBox:GetText())
        if val then
            RT.db.goals = RT.db.goals or {}
            if val <= 0 then
                RT.db.goals[data.key] = nil
            else
                RT.db.goals[data.key] = val
            end
            RT:UpdateTracker()
        end
    end,
    EditBoxOnEnterPressed = function(self)
        local parent = self:GetParent()
        StaticPopupDialogs["RT_SET_GOAL"].OnAccept(parent, parent.data)
        parent:Hide()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}