local addonName, RT = ...

-- Допоміжна функція для ключів БД
local function GetReagentKey(entry)
    if type(entry) == "table" then return table.concat(entry, "_") end
    return tostring(entry)
end

-- Отримання іконки якості (збільшена до 25x25)
local function GetQualityIcon(quality)
    if not quality or quality < 1 or quality > 3 then return "" end
    local atlas = ({"Professions-Icon-Quality-Tier1", "Professions-Icon-Quality-Tier2", "Professions-Icon-Quality-Tier3"})[quality]
    return CreateAtlasMarkup(atlas, 25, 25)
end

-- Отримання кольору класу для імені персонажа
local function GetClassColorName(name)
    local _, classFile = UnitClass(name)
    if not classFile then return "|cffcccccc" .. name .. "|r" end
    local color = RAID_CLASS_COLORS[classFile]
    return string.format("|c%s%s|r", color.colorStr, name)
end

-- =====================
-- ДЕТАЛІЗАЦІЯ (TSM STYLE)
-- =====================
local detailFrame = CreateFrame("Frame", "RT_DetailMenu", UIParent, "BackdropTemplate")
detailFrame:SetClampedToScreen(true)
detailFrame:SetFrameStrata("TOOLTIP")
detailFrame:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
detailFrame:SetBackdropColor(0, 0, 0, 0.95)
detailFrame:Hide()

local close = CreateFrame("Button", nil, detailFrame, "UIPanelCloseButton")
close:SetPoint("TOPRIGHT", 2, 2)
close:SetScale(0.8)
close:SetScript("OnClick", function() detailFrame:Hide() end)

detailFrame.rows = {}

local function ShowDetailMenu(anchor, entry, title)
    detailFrame:ClearAllPoints()
    detailFrame:SetPoint("TOPLEFT", anchor, "TOPRIGHT", 15, 0)
    detailFrame:Show()
    
    for _, row in ipairs(detailFrame.rows) do 
        row:Hide() 
        if row.subRows then for _, sr in ipairs(row.subRows) do sr:Hide() end end
    end

    if not detailFrame.title then
        detailFrame.title = detailFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        detailFrame.title:SetPoint("TOPLEFT", 12, -12)
    end
    detailFrame.title:SetText("|cffffd100" .. title .. "|r")

    local yOffset = -38
    local rowIndex = 1
    
    local ICON_SIZE = 26       
    local ROW_HEIGHT_ITEM = 30 
    local ROW_HEIGHT_SUB = 16  
    local MENU_WIDTH = 280     

    for _, id in ipairs(entry) do
        local bags = C_Item.GetItemCount(id, false, false, false, false)
        local bank = C_Item.GetItemCount(id, true, false, false, false) - bags
        local warband = C_Item.GetItemCount(id, true, false, true, true) - (bags + bank)
        local total = bags + bank + warband

        if total > 0 then
            if not detailFrame.rows[rowIndex] then
                local r = CreateFrame("Frame", nil, detailFrame)
                r:SetSize(MENU_WIDTH - 20, ROW_HEIGHT_ITEM)
                
                r.icon = r:CreateTexture(nil, "ARTWORK")
                r.icon:SetSize(ICON_SIZE, ICON_SIZE)
                r.icon:SetPoint("LEFT", 5, 0)
                
                r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0)
                
                r.total = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                r.total:SetPoint("RIGHT", -5, 0)
                
                r.subRows = {}
                detailFrame.rows[rowIndex] = r
            end
            
            local r = detailFrame.rows[rowIndex]
            local q = C_TradeSkillUI.GetItemReagentQualityByItemInfo(id)
            r.icon:SetTexture(C_Item.GetItemIconByID(id))
            r.name:SetText((C_Item.GetItemNameByID(id) or "...") .. " " .. GetQualityIcon(q))
            r.total:SetText("|cffffffffTotal: " .. total .. "|r")
            r:SetPoint("TOPLEFT", 10, yOffset)
            r:Show()

            -- ФІКС ТУЛТІПА: Тепер він прив'язаний до всього вікна меню, а не до рядка
            r:EnableMouse(true)
            r:SetScript("OnEnter", function()
                GameTooltip:SetOwner(detailFrame, "ANCHOR_NONE") -- Прибираємо стандартний якір
                GameTooltip:SetPoint("TOPLEFT", detailFrame, "TOPRIGHT", 10, 0) -- Ставимо тултіп праворуч від меню
                GameTooltip:SetItemByID(id)
                GameTooltip:Show()
            end)
            r:SetScript("OnLeave", function() GameTooltip:Hide() end)
            
            yOffset = yOffset - ROW_HEIGHT_ITEM

            local locations = {
                {name = GetClassColorName(UnitName("player")), bags = bags, bank = bank},
                {name = "|cffeda55fWarband|r", total = warband}
            }

            for i, loc in ipairs(locations) do
                if (loc.bags and (loc.bags > 0 or loc.bank > 0)) or (loc.total and loc.total > 0) then
                    if not r.subRows[i] then
                        local sr = CreateFrame("Frame", nil, detailFrame)
                        sr:SetSize(MENU_WIDTH - 30, ROW_HEIGHT_SUB)
                        sr.char = sr:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
                        sr.char:SetPoint("LEFT", 40, 0)
                        sr.details = sr:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
                        sr.details:SetPoint("RIGHT", -5, 0)
                        r.subRows[i] = sr
                    end
                    local sr = r.subRows[i]
                    sr.char:SetText(loc.name)
                    
                    if loc.total then
                        sr.details:SetText("|cff80c7ffTotal:|r " .. loc.total)
                    else
                        local parts = {}
                        if loc.bags > 0 then table.insert(parts, "|cff80c7ffBags:|r " .. loc.bags) end
                        if loc.bank > 0 then table.insert(parts, "|cff80c7ffBank:|r " .. loc.bank) end
                        sr.details:SetText(table.concat(parts, " "))
                    end
                    sr:SetPoint("TOPLEFT", 0, yOffset)
                    sr:Show()
                    yOffset = yOffset - ROW_HEIGHT_SUB
                end
            end
            yOffset = yOffset - 8
            rowIndex = rowIndex + 1
        end
    end
    detailFrame:SetSize(MENU_WIDTH, math.abs(yOffset) + 12)
end

-- =====================
-- ТРЕКЕР
-- =====================
function RT:CreateTracker()
    if self.frame then return end
    self.frame = CreateFrame("Frame", "RT_MainFrame", UIParent)
    local p = self.db.position
    self.frame:SetPoint(p.point, UIParent, p.relativePoint, p.x, p.y)
    self.frame:SetMovable(true)
    self.frame:SetClampedToScreen(true)
    self.frame:EnableMouse(true)
    self.icons = {}
end

function RT:GetGroupedItemCount(entry)
    if type(entry) == "table" then
        local t = 0
        for _, id in ipairs(entry) do t = t + C_Item.GetItemCount(id, true, false, true, true) end
        return t
    end
    return C_Item.GetItemCount(entry, true, false, true, true)
end

function RT:UpdateTracker()
    if not self.frame then return end
    RT.db.goals = RT.db.goals or {}
    for _, f in ipairs(self.icons) do f:Hide() end
    wipe(self.icons)

    local activeElements = {}
    local function Collect(data, exp)
        if exp and RT.db.showExpansion[exp] == false then return end
        if type(data) == "table" and data[1] then
            for _, e in ipairs(data) do if self.db.enabled[GetReagentKey(e)] then table.insert(activeElements, e) end end
        else
            for _, sub in pairs(data) do if type(sub) == "table" then Collect(sub, exp) end end
        end
    end
    for k, v in pairs(RT_REAGENTS) do Collect(v, k) end

    local offsetX, offsetY = 0, 0
    local totalW, totalH = 0, 0
    local pos = RT.db.textPosition or "Right"

    for _, entry in ipairs(activeElements) do
        local key = GetReagentKey(entry)
        local displayID = type(entry) == "table" and entry[1] or entry
        local count = self:GetGroupedItemCount(entry)
        local goal = RT.db.goals[key]

        local row = CreateFrame("Frame", nil, self.frame)
        row:SetSize(RT.db.iconSize, RT.db.iconSize)
        row:EnableMouse(true)
        row:RegisterForDrag("LeftButton")

        local tex = row:CreateTexture(nil, "ARTWORK")
        tex:SetAllPoints(row)
        tex:SetTexture(C_Item.GetItemIconByID(displayID))

        local txt = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        txt:SetFont(txt:GetFont(), RT.db.nameFontSize)
        local nameStr = C_Item.GetItemNameByID(displayID) or "Loading..."
        
        if RT.db.showCountInName then
            local dCount = goal and string.format("%d/%d", count, goal) or count
            txt:SetText(string.format("%s: %s", nameStr, dCount))
        else
            txt:SetText(nameStr)
        end
        
        txt:ClearAllPoints()
        if pos == "Right" then 
            txt:SetPoint("LEFT", row, "RIGHT", 8, 0)
            txt:SetJustifyH("LEFT")
        elseif pos == "Left" then 
            txt:SetPoint("RIGHT", row, "LEFT", -8, 0)
            txt:SetJustifyH("RIGHT")
        elseif pos == "Top" then 
            txt:SetPoint("BOTTOM", row, "TOP", 0, 4)
            txt:SetJustifyH("CENTER")
        elseif pos == "Bottom" then 
            txt:SetPoint("TOP", row, "BOTTOM", 0, -4)
            txt:SetJustifyH("CENTER")
        end
        txt:SetShown(RT.db.showNames)
        if goal and count >= goal then txt:SetTextColor(0, 1, 0) else txt:SetTextColor(1, 0.82, 0) end

        local fsIcon = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        fsIcon:SetDrawLayer("OVERLAY", 7)
        fsIcon:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -1, 1)
        fsIcon:SetFont(fsIcon:GetFont(), RT.db.counterFontSize, "OUTLINE")
        fsIcon:SetText(count)
        fsIcon:SetShown(RT.db.showCountOnIcon)

        row:SetScript("OnEnter", function(s)
            GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
            if type(entry) == "table" then
                GameTooltip:AddLine(nameStr, 1, 0.82, 0)
                for _, id in ipairs(entry) do
                    local tc = C_Item.GetItemCount(id, true, false, true, true)
                    if tc > 0 then
                        local q = C_TradeSkillUI.GetItemReagentQualityByItemInfo(id)
                        GameTooltip:AddDoubleLine(GetQualityIcon(q) .. " " .. (C_Item.GetItemNameByID(id) or ""), tc, 1,1,1, 1,1,1)
                    end
                end
                GameTooltip:AddLine("\n|cff00ff00<Left-Click to Pin Menu>|r")
            else GameTooltip:SetItemByID(displayID) end
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
        row:SetScript("OnMouseDown", function(_, btn)
            if btn == "LeftButton" and type(entry) == "table" then ShowDetailMenu(row, entry, nameStr)
            elseif btn == "RightButton" then 
                local popup = StaticPopup_Show("RT_SET_GOAL")
                if popup then popup.data = { key = key } end
            end
        end)
        row:SetScript("OnDragStart", function() if not RT.db.locked then self.frame:StartMoving() end end)
        row:SetScript("OnDragStop", function() 
            self.frame:StopMovingOrSizing() 
            local p, _, rp, x, y = self.frame:GetPoint()
            RT.db.position = { point = p, relativePoint = rp, x = x, y = y }
        end)

        local stepW = RT.db.iconSize + RT.db.spacing
        local stepH = RT.db.iconSize + RT.db.spacing
        if RT.db.showNames and (pos == "Top" or pos == "Bottom") then
            stepH = stepH + txt:GetStringHeight() + 4
        end

        if RT.db.orientation == "Horizontal" then
            row:SetPoint("LEFT", self.frame, "LEFT", offsetX, 0)
            offsetX = offsetX + stepW + (RT.db.showNames and (pos == "Right" or pos == "Left") and (txt:GetStringWidth() + 8) or 0)
            totalW, totalH = offsetX, stepH
        else
            row:SetPoint("TOP", self.frame, "TOP", 0, offsetY)
            offsetY = offsetY - stepH
            totalW, totalH = math.max(totalW, (RT.db.showNames and (pos == "Right" or pos == "Left") and (stepW + txt:GetStringWidth() + 8) or stepW)), math.abs(offsetY)
        end
        table.insert(self.icons, row)
    end
    self.frame:SetSize(totalW > 0 and totalW or 32, totalH > 0 and totalH or 32)
end