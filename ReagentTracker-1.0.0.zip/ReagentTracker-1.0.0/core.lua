ReagentTracker = {}
RT = ReagentTracker

local defaults = {
    enabled = {},
    showExpansion = {}, -- Нове: фільтр видимості цілих доповнень
    iconSize = 32,
    counterFontSize = 14,
    nameFontSize = 12,
    showNames = true,
    showCountOnIcon = true,
    showCountInName = false,
    orientation = "Vertical",
    textPosition = "Right",
    scale = 1,
    locked = false,
    spacing = 6,

    position = {
        point = "CENTER",
        relativePoint = "CENTER",
        x = 0,
        y = 0,
    },
}

local function CopyDefaults(src, dst)
    if type(dst) ~= "table" then dst = {} end
    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
    
    if dst.layout then
        dst.orientation = (dst.layout == "horizontal") and "Horizontal" or "Vertical"
        dst.layout = nil
    end

    return dst
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("BAG_UPDATE_DELAYED")

f:SetScript("OnEvent", function(_, event, addon)
    if event == "ADDON_LOADED" and addon == "ReagentTracker" then
        ReagentTrackerDB = CopyDefaults(defaults, ReagentTrackerDB or {})
        RT.db = ReagentTrackerDB
    end

    if event == "PLAYER_LOGIN" then
        RT:CreateTracker()
        C_Timer.After(1, function() RT:UpdateTracker() end)
    end

    if event == "BAG_UPDATE_DELAYED" then
        RT:UpdateTracker()
    end
end)