local panel = CreateFrame("Frame")
panel.name = "Reagent Tracker"

local EXPANSION_NAMES = {
    General      = "General",
    Lumber       = "Lumber",
    Classic      = "Classic",
    Outland      = "Outland",
    Wotlk        = "WoTLK",
    Cataclysm    = "Cataclysm",
    Pandaria     = "Pandaria",
    Draenor      = "Draenor",
    Legion       = "Legion",
    Bfa          = "Battle for Amazon",
    Shadowlands  = "Shadowlands",
    DragonIsles  = "Dragon Isles",
    TheWarWithin = "The War Within",
}

local TAB_ORDER = { "General", "Lumber", "Classic", "Outland", "Wotlk", "Cataclysm", "Pandaria", "Draenor", "Legion", "Bfa", "Shadowlands", "DragonIsles", "TheWarWithin" }

panel.Tabs = {} 
local ICON_SIZE = 32
local ICONS_PER_ROW = 8
local ROW_SPACING = 68

-- Допоміжний об'єкт для розрахунку ширини тексту
local calcFS = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
calcFS:Hide()

-- =====================
-- ДОПОМІЖНІ ФУНКЦІЇ
-- =====================

local function CreateScrollableContent(parent)
    local scrollFrame = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 5, -5)
    scrollFrame:SetPoint("BOTTOMRIGHT", -25, 5)

    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(580, 100)
    scrollFrame:SetScrollChild(content)
    
    return content, scrollFrame
end

local function CreateTab(name, index)
    local tab = CreateFrame("Button", "RT_Tab"..index, panel, "PanelTabButtonTemplate")
    tab:SetID(index)
    tab:SetText(name)
    
    -- 1. ПЕРЕВЕРТАЄМО ТЕКСТУРИ (вушками вгору)
    local regions = { tab:GetRegions() }
    for _, reg in ipairs(regions) do
        if reg:IsObjectType("Texture") then 
            reg:SetTexCoord(0, 1, 1, 0) 
        end
    end

    -- 2. НАЛАШТУВАННЯ ТЕКСТОВОЇ ОБЛАСТІ
    local btnText = tab:GetFontString()
    if btnText then
        btnText:ClearAllPoints()
        btnText:SetPoint("LEFT", tab, "LEFT", 12, 0)
        btnText:SetPoint("RIGHT", tab, "RIGHT", -12, 0)
        btnText:SetJustifyH("CENTER")
    end

    -- 3. ТОЧНИЙ РОЗРАХУНОК ШИРИНИ
    calcFS:SetText(name)
    local textWidth = calcFS:GetStringWidth()
    -- Використовуємо парне число для ширини, щоб уникнути мікро-зсувів текстур
    local finalWidth = math.ceil((textWidth + 28) / 2) * 2 
    finalWidth = math.max(64, finalWidth)
    
    tab:SetSize(finalWidth, 32)
    tab.minWidth = finalWidth
    
    tab:SetScript("OnClick", function() 
        panel.selectedTab = index
        PanelTemplates_SetTab(panel, index)
        for i, t in ipairs(panel.Tabs) do 
            if t.contentFrame then t.contentFrame:SetShown(i == index) end 
        end
    end)
    
    panel.Tabs[index] = tab
    return tab
end

local function LayoutTabs()
    local MAX_WIDTH = 610
    local startX, startY = 15, -30
    local currentX = startX
    local currentRowY = startY
    local rowHeight = 36
    local horizontalSpacing = 1 -- Фіксований відступ між табами

    for i, tab in ipairs(panel.Tabs) do
        tab:ClearAllPoints()
        local tabWidth = tab:GetWidth()

        -- Перевірка на перенос рядка
        if currentX + tabWidth > MAX_WIDTH and i > 1 then
            currentX = startX
            currentRowY = currentRowY - rowHeight
        end

        tab:SetPoint("TOPLEFT", panel, "TOPLEFT", currentX, currentRowY)
        currentX = currentX + tabWidth + horizontalSpacing
    end
    -- Повертаємо загальну висоту, яку зайняли таби
    return math.abs(currentRowY) + rowHeight
end

-- =====================
-- КОНТЕНТ ТАБІВ
-- =====================

local function CreateGeneralOptions(parent)
    local title = parent:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 20, -10); title:SetText("General Settings")

    local lock = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    lock:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -10)
    lock.text:SetText("Lock Tracker Position")
    lock:SetChecked(RT.db.locked)
    lock:SetScript("OnClick", function(self) RT.db.locked = self:GetChecked() end)

    local orientBtn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    orientBtn:SetPoint("TOPLEFT", lock, "BOTTOMLEFT", 0, -10)
    orientBtn:SetSize(160, 25)
    orientBtn:SetText("Orientation: " .. (RT.db.orientation or "Vertical"))
    orientBtn:SetScript("OnClick", function(self)
        RT.db.orientation = (RT.db.orientation == "Vertical") and "Horizontal" or "Vertical"
        self:SetText("Orientation: " .. RT.db.orientation); RT:UpdateTracker()
    end)

    local names = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    names:SetPoint("TOPLEFT", orientBtn, "BOTTOMLEFT", 0, -10)
    names.text:SetText("Show Reagent Names")
    names:SetChecked(RT.db.showNames)
    names:SetScript("OnClick", function(self) RT.db.showNames = self:GetChecked(); RT:UpdateTracker() end)

    local labelPos = parent:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    labelPos:SetPoint("TOPLEFT", names, "BOTTOMLEFT", 25, -5); labelPos:SetText("Text Position:")

    local dropdown = CreateFrame("Frame", "RT_TextPosDropdown", parent, "UIDropDownMenuTemplate")
    dropdown:SetPoint("LEFT", labelPos, "RIGHT", -15, -2); UIDropDownMenu_SetWidth(dropdown, 80)
    UIDropDownMenu_SetText(dropdown, RT.db.textPosition or "Right")
    UIDropDownMenu_Initialize(dropdown, function()
        for _, side in ipairs({"Left", "Right", "Top", "Bottom"}) do
            local info = UIDropDownMenu_CreateInfo()
            info.text, info.func = side, function()
                RT.db.textPosition = side; UIDropDownMenu_SetText(dropdown, side); RT:UpdateTracker()
            end
            UIDropDownMenu_AddButton(info)
        end
    end)

    local cIcon = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cIcon:SetPoint("TOPLEFT", labelPos, "BOTTOMLEFT", -5, -10)
    cIcon.text:SetText("Count on Icon")
    cIcon:SetChecked(RT.db.showCountOnIcon)
    cIcon:SetScript("OnClick", function(self) RT.db.showCountOnIcon = self:GetChecked(); RT:UpdateTracker() end)

    local cName = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cName:SetPoint("TOPLEFT", cIcon, "BOTTOMLEFT", 0, -5)
    cName.text:SetText("Count in Name")
    cName:SetChecked(RT.db.showCountInName)
    cName:SetScript("OnClick", function(self) RT.db.showCountInName = self:GetChecked(); RT:UpdateTracker() end)

    local expTitle = parent:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    expTitle:SetPoint("TOPLEFT", parent, "TOP", 60, -10); expTitle:SetText("Show Expansions:")

    local lastExp = expTitle
    for _, key in ipairs(TAB_ORDER) do
        if key ~= "General" then
            local cb = CreateFrame("CheckButton", nil, parent, "InterfaceOptionsCheckButtonTemplate")
            cb:SetPoint("TOPLEFT", lastExp, "BOTTOMLEFT", 0, -2)
            cb.Text:SetText(EXPANSION_NAMES[key] or key)
            cb:SetChecked(RT.db.showExpansion[key] ~= false)
            cb:SetScript("OnClick", function(self) RT.db.showExpansion[key] = self:GetChecked(); RT:UpdateTracker() end)
            lastExp = cb
        end
    end

    local function CreateSlider(label, min, max, dbKey, yOff)
        local s = CreateFrame("Slider", nil, parent, "OptionsSliderTemplate")
        s:SetPoint("TOPLEFT", cName, "BOTTOMLEFT", -10, yOff)
        s:SetMinMaxValues(min, max); s:SetValueStep(1); s:SetWidth(180)
        s.Text:SetText(label .. ": " .. (RT.db[dbKey] or min))
        s:SetValue(RT.db[dbKey] or min)
        s:SetScript("OnValueChanged", function(self, v)
            v = math.floor(v); RT.db[dbKey] = v; self.Text:SetText(label .. ": " .. v); RT:UpdateTracker()
        end)
        return s
    end

    CreateSlider("Icon Size", 16, 64, "iconSize", -45)
    CreateSlider("Counter Font", 8, 30, "counterFontSize", -85)
    CreateSlider("Name Font", 8, 24, "nameFontSize", -125)
    CreateSlider("Spacing", 0, 50, "spacing", -165)
    
    local reset = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    reset:SetPoint("TOPLEFT", cName, "BOTTOMLEFT", 0, -220) 
    reset:SetSize(130, 25); reset:SetText("Reset Position")
    reset:SetScript("OnClick", function()
        RT.db.position = { point = "CENTER", relativePoint = "CENTER", x = 0, y = 0 }
        RT.frame:ClearAllPoints(); RT.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end)
    
    parent:SetHeight(550) 
end

local function PopulateExpansionTab(frame, key)
    local data = RT_REAGENTS[key]
    if not data then return end
    local y, loopData = -15, (data[1] ~= nil) and { [EXPANSION_NAMES[key] or key] = data } or data

    for catName, reagents in pairs(loopData) do
        local h = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
        h:SetPoint("TOPLEFT", 20, y); h:SetText(catName); h:SetTextColor(1, 0.82, 0)
        y = y - 25
        local col, row = 0, 0
        for _, entry in ipairs(reagents) do
            local itemKey = (type(entry) == "table") and table.concat(entry, "_") or tostring(entry)
            local displayID = type(entry) == "table" and entry[1] or entry
            local btn = CreateFrame("Button", nil, frame)
            btn:SetPoint("TOPLEFT", 20 + col * (ICON_SIZE + 40), y - row * ROW_SPACING)
            btn:SetSize(ICON_SIZE, ICON_SIZE + 28)

            local icon = btn:CreateTexture(nil, "ARTWORK")
            icon:SetSize(ICON_SIZE, ICON_SIZE); icon:SetPoint("TOP")
            icon:SetTexture(C_Item.GetItemIconByID(displayID))

            local nameText = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            nameText:SetPoint("TOP", icon, "BOTTOM", 0, -4); nameText:SetWidth(ICON_SIZE + 35)
            nameText:SetJustifyH("CENTER"); nameText:SetWordWrap(true)
            nameText:SetText(C_Item.GetItemNameByID(displayID) or "...")

            local function UpdateVisuals()
                local active = RT.db.enabled[itemKey]
                icon:SetAlpha(active and 1 or 0.3)
                nameText:SetTextColor(active and 1 or 0.5, active and 1 or 0.5, active and 1 or 0.5)
            end
            btn:SetScript("OnClick", function() RT.db.enabled[itemKey] = not RT.db.enabled[itemKey]; UpdateVisuals(); RT:UpdateTracker() end)
            UpdateVisuals()

            col = col + 1
            if col >= ICONS_PER_ROW then col = 0; row = row + 1 end
        end
        y = y - (row + 1) * ROW_SPACING - 15
    end
    frame:SetHeight(math.abs(y) + 20)
end

-- =====================
-- ІНІЦІАЛІЗАЦІЯ
-- =====================

panel:SetScript("OnShow", function(self)
    if self.initialized then return end
    
    -- Створюємо всі таби та їх контент
    for i, key in ipairs(TAB_ORDER) do
        local tab = CreateTab(EXPANSION_NAMES[key] or key, i)
        local wrapper = CreateFrame("Frame", nil, panel)
        tab.contentFrame = wrapper
        
        local scrollChild, _ = CreateScrollableContent(wrapper)
        if key == "General" then CreateGeneralOptions(scrollChild) else PopulateExpansionTab(scrollChild, key) end
    end

    -- Вибудовуємо таби та отримуємо висоту, яку вони зайняли
    local totalTabsHeight = LayoutTabs()

    -- Коригуємо позиції контенту та роздільної лінії
    for _, tab in ipairs(panel.Tabs) do
        tab.contentFrame:SetPoint("TOPLEFT", 0, -(totalTabsHeight + 15))
        tab.contentFrame:SetPoint("BOTTOMRIGHT", 0, 5)
        tab.contentFrame:Hide()
    end

    local line = panel:CreateTexture(nil, "ARTWORK")
    line:SetTexture("Interface\\Common\\UI-TooltipDivider-Transparent")
    line:SetHeight(2); line:SetAlpha(0.7)
    line:SetPoint("TOPLEFT", panel, "TOPLEFT", 15, -totalTabsHeight - 10)
    line:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -15, -totalTabsHeight - 10)

    panel.numTabs = #panel.Tabs 
    panel.selectedTab = 1
    PanelTemplates_SetTab(panel, 1)
    panel.Tabs[1].contentFrame:Show()
    
    self.initialized = true
end)

local category = Settings.RegisterCanvasLayoutCategory(panel, panel.name)
Settings.RegisterAddOnCategory(category)

SLASH_REAGENTTRACKER1 = "/reagentstracker"
SLASH_REAGENTTRACKER2 = "/reagents"
SLASH_REAGENTTRACKER3 = "/rtr"

SlashCmdList["REAGENTTRACKER"] = function(msg)
    if category then Settings.OpenToCategory(category:GetID()) else InterfaceOptionsFrame_OpenToCategory("Reagent Tracker") end
end