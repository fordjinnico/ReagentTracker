local function GetReagentKey(entry)
    if type(entry) == "table" then
        return table.concat(entry, "_")
    end
    return tostring(entry)
end

-- =====================
-- ВІКНО ВВОДУ ЦІЛІ
-- =====================
StaticPopupDialogs["RT_SET_GOAL"] = {
    text = "Set goal amount (0 to clear):",
    button1 = "OK",
    button2 = "Cancel",
    hasEditBox = true,
    OnAccept = function(self, data)
        -- Виправляємо звернення до EditBox для актуальних версій WoW
        local eb = self.EditBox or _G[self:GetName().."EditBox"]
        local text = eb:GetText()
        local amount = tonumber(text)
        
        if data and data.key then
            RT.db.goals = RT.db.goals or {}
            RT.db.goals[data.key] = (amount and amount > 0) and amount or nil
            RT:UpdateTracker()
        end
    end,
    EditBoxOnEnterPressed = function(self)
        local parent = self:GetParent()
        StaticPopupDialogs["RT_SET_GOAL"].OnAccept(parent, parent.data)
        parent:Hide()
    end,
    OnShow = function(self)
        local eb = self.EditBox or _G[self:GetName().."EditBox"]
        eb:SetText("")
        eb:SetFocus()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}

-- =====================
-- СТВОРЕННЯ ТРЕКЕРА
-- =====================
function RT:CreateTracker()
    if self.frame then return end
    local f = CreateFrame("Frame", "RT_MainFrame", UIParent)
    local pos = self.db.position
    f:SetPoint(pos.point, UIParent, pos.relativePoint, pos.x, pos.y)
    f:SetScale(self.db.scale or 1)
    f:SetSize(1, 1)
    
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    
    self.frame = f
    self.icons = {}
end

function RT:GetGroupedItemCount(entry)
    local function count(id) return C_Item.GetItemCount(id, true, false, true, true) end
    if type(entry) == "table" then
        local total = 0
        for _, id in ipairs(entry) do total = total + count(id) end
        return total
    end
    return count(entry)
end

function RT:GetDisplayInfo(entry)
    local id = type(entry) == "table" and entry[1] or entry
    return C_Item.GetItemIconByID(id), C_Item.GetItemNameByID(id)
end

-- =====================
-- ОНОВЛЕННЯ ТРЕКЕРА
-- =====================
function RT:UpdateTracker()
    if not self.frame then return end
    RT.db.goals = RT.db.goals or {}

    local iconSize = self.db.iconSize or 32
    local spacing = self.db.spacing or 6
    local counterFS = self.db.counterFontSize or 14
    local nameFS = self.db.nameFontSize or 12
    local isHoriz = self.db.orientation == "Horizontal"
    local textPos = self.db.textPosition or "Right"

    -- Очищення старих іконок
    for _, f in ipairs(self.icons) do f:Hide() end
    wipe(self.icons)

    local activeElements = {}
    local function CollectReagents(data, expKey)
        if expKey and RT.db.showExpansion[expKey] == false then return end
        if type(data) == "table" and data[1] then
            for _, entry in ipairs(data) do
                if self.db.enabled[GetReagentKey(entry)] then table.insert(activeElements, entry) end
            end
        else
            for _, subData in pairs(data) do 
                if type(subData) == "table" then CollectReagents(subData, expKey) end 
            end
        end
    end

    for expKey, expData in pairs(RT_REAGENTS) do CollectReagents(expData, expKey) end

    -- Розрахунок максимальної ширини тексту
    local maxTextWidth = 0
    if self.db.showNames then
        local tempFS = self.frame:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
        tempFS:SetFont(tempFS:GetFont(), nameFS)
        for _, entry in ipairs(activeElements) do
            local _, name = self:GetDisplayInfo(entry)
            tempFS:SetText(name or "")
            maxTextWidth = math.max(maxTextWidth, tempFS:GetStringWidth())
        end
        tempFS:Hide()
    end

    local offsetX, offsetY = 0, 0
    local totalWidth, totalHeight = 0, 0

    for _, entry in ipairs(activeElements) do
        local key = GetReagentKey(entry)
        local icon, name = self:GetDisplayInfo(entry)
        local itemCount = self:GetGroupedItemCount(entry)
        local goal = RT.db.goals[key]

        -- Створюємо контейнер для кожного рядка
        local row = CreateFrame("Frame", nil, self.frame)
        row:EnableMouse(true)
        row:RegisterForDrag("LeftButton") -- Реєструємо Drag для рядка

        -- Обробка кліків
        row:SetScript("OnMouseDown", function(_, btn)
            if btn == "RightButton" then
                local dialog = StaticPopup_Show("RT_SET_GOAL")
                if dialog then dialog.data = { key = key } end
            end
        end)

        -- ЛОГІКА ПЕРЕТЯГУВАННЯ (через рядок рухаємо головний фрейм)
        row:SetScript("OnDragStart", function() 
            if not RT.db.locked then self.frame:StartMoving() end 
        end)
        row:SetScript("OnDragStop", function() 
            self.frame:StopMovingOrSizing() 
            local point, _, rel, x, y = self.frame:GetPoint()
            RT.db.position = { point = point, relativePoint = rel, x = x, y = y }
        end)
        
        -- Іконка
        local tex = row:CreateTexture(nil, "ARTWORK")
        tex:SetSize(iconSize, iconSize)
        tex:SetTexture(icon)

        -- Шрифт на іконці
        local countOnIcon = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        countOnIcon:SetPoint("BOTTOMRIGHT", tex, "BOTTOMRIGHT", -2, 2)
        countOnIcon:SetFont(countOnIcon:GetFont(), counterFS, "OUTLINE")
        
        local displayCount = goal and string.format("%d/%d", itemCount, goal) or itemCount
        countOnIcon:SetText(displayCount)
        
        if goal and itemCount >= goal then
            countOnIcon:SetTextColor(0, 1, 0) 
        else
            countOnIcon:SetTextColor(1, 1, 1)
        end
        countOnIcon:SetShown(self.db.showCountOnIcon)

        -- Назва ресурсу
        local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        nameText:SetFont(nameText:GetFont(), nameFS)
        local displayString = name or ""
        if self.db.showCountInName then displayString = string.format("%s: %s", displayString, displayCount) end
        nameText:SetText(displayString)
        nameText:SetShown(self.db.showNames)
        
        if goal and itemCount >= goal then 
            nameText:SetTextColor(0, 1, 0) 
        else 
            nameText:SetTextColor(1, 0.82, 0)
        end

        -- Позиціонування елементів всередині рядка
        local rowW, rowH = iconSize, iconSize
        if not self.db.showNames then
            tex:SetPoint("CENTER", row, "CENTER")
        elseif textPos == "Right" then
            tex:SetPoint("LEFT", row, "LEFT"); nameText:SetPoint("LEFT", tex, "RIGHT", 6, 0)
            nameText:SetJustifyH("LEFT"); rowW = iconSize + 6 + maxTextWidth + (self.db.showCountInName and 50 or 0)
        elseif textPos == "Left" then
            tex:SetPoint("RIGHT", row, "RIGHT"); nameText:SetPoint("RIGHT", tex, "LEFT", -6, 0)
            nameText:SetJustifyH("RIGHT"); rowW = iconSize + 6 + maxTextWidth + (self.db.showCountInName and 50 or 0)
        elseif textPos == "Top" then
            nameText:SetPoint("TOP", row, "TOP"); tex:SetPoint("TOP", nameText, "BOTTOM", 0, -2)
            nameText:SetJustifyH("CENTER"); rowH = iconSize + 2 + nameText:GetStringHeight(); rowW = math.max(iconSize, maxTextWidth)
        elseif textPos == "Bottom" then
            tex:SetPoint("TOP", row, "TOP"); nameText:SetPoint("TOP", tex, "BOTTOM", 0, -2)
            nameText:SetJustifyH("CENTER"); rowH = iconSize + 2 + nameText:GetStringHeight(); rowW = math.max(iconSize, maxTextWidth)
        end

        -- Розміщення самого рядка у головному фреймі
        row:SetSize(rowW, rowH)
        if isHoriz then
            row:SetPoint("LEFT", self.frame, "LEFT", offsetX, 0); offsetX = offsetX + rowW + spacing
            totalHeight = math.max(totalHeight, rowH); totalWidth = offsetX
        else
            row:SetPoint("TOP", self.frame, "TOP", 0, offsetY); offsetY = offsetY - (rowH + spacing)
            totalWidth = math.max(totalWidth, rowW); totalHeight = math.abs(offsetY)
        end
        table.insert(self.icons, row)
    end

    -- Фінальний розмір вікна трекера
    self.frame:SetSize(totalWidth > 0 and totalWidth or 100, totalHeight > 0 and totalHeight or 20)
    self.frame:SetShown(#self.icons > 0)
end